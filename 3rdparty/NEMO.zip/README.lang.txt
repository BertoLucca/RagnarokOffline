﻿To add a new Language simply create a file named UI_<language name>.ini and 
fill all the fields (refer UI_English.ini and Template_UI.ini files for more details)
It will automatically get displayed as part of the Change Language menu.
If any of the fields are missing a blankspace would be displayed in its place.
