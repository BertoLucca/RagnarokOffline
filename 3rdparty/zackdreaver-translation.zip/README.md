## ROenglishPRE
Project created by **zackdreaver** @2015

[ROenglishPRE](https://rathena.org/board/topic/102689-ragnarok-english-translation-project/) is an unofficial english translation (Fan translation) project for Ragnarok Online Pre-Renewal (Not to be confused with Classic aka Pre-Transcendent).

Note: this project should be considered as educational purposes only, any commercial or illegal use by people or group aren't author's responsibilities.

## Prerequisites
* [Renewal Project](https://github.com/zackdreaver/ROenglishRE), paste all files from ROenglishPRE to renewal project
