# Classes reference

- Classes
  - [BinFile](binfile.md)
  - [TextFile](textfile.md)
