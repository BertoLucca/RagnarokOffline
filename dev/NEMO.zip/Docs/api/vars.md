# Global vars reference


## APP_PATH

Nemo path.

## PLUGIN_VERSION

Plugin version.

## SRC_CLIENT_FILE

Path of selected source client exe.

## DST_CLIENT_FILE

Path of selected destination client exe.

## IS_RO

Set to true is any supported ragnarok client loaded.
