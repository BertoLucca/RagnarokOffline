# Objects reference

- Objects
  - [asm](asm.md)
  - [exe](exe.md)
